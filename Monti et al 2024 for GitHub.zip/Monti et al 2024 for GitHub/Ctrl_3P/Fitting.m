% Model simulation post-parameter estimation
function Fitting(mpar,PerFlow,BileFlow,PerVolume,IC,tData,PerfusateData,BileData,PerfusateSEM,BileSEM,FH)

p = Parameters(mpar,PerFlow,BileFlow,PerVolume); %load parameters into model
y0 = [IC 0 0 0 0 0 0 0 0 0]; % Initial concentrations in mg/ml 

tf = 1;
tspan = tf*(0:1:60);

options = odeset('RelTol',1e-6,'AbsTol',1e-6,'InitialStep',1e-2,...
    'NonNegative',(1:10),'MaxOrder',5,'BDF','on','Stats','off');

% Calculate model solution
ODE_FH = @(t,y)LiverModel(t,y,p);
sols = ode15s(ODE_FH,tspan,y0,options);
y = deval(tspan,sols);

% Assigning models
PerfusateModel = y(1,:)';  %mg/ml
BileModel = y(9,:)';  %mg/ml

% Plot model simulation compared to experimental data
figure(FH); set(gcf,'Units','inches','Position',[0.5 0.5 7 5]);
set(gcf,'Units','inches','PaperPosition',[0.5 0.5 7 5],'color','white');

plot(tspan,PerfusateModel*100,'-r','LineWidth',2); hold on;
errorbar(tData,PerfusateData*100,PerfusateSEM*100,'o','MarkerSize',6,'MarkerFaceColor',...
    'r','MarkerEdgeColor','r','LineWidth',2,'Color','r','CapSize',6); hold on;
plot(tspan,BileModel*100,'-g','LineWidth',2); hold on;
errorbar(tData,BileData*100,BileSEM*100,'o','MarkerSize',6,'MarkerFaceColor',...
    'g','MarkerEdgeColor','g','LineWidth',2,'Color','g','CapSize',6); hold on;

axis([0 tf*60 0 1]); box on; grid off
set(gca,'LineWidth',1.5,'FontSize',18); box off;
set(gca,'XTick',tf*(0:10:60),'YTick',(0:0.25:1));
xlabel("Time (min)"); ylabel("Concentration x 10^2 (mg/mL)")

h = legend("Perfusate Model","Perfusate Data","Bile Model","Bile Data",...
    "Location","NorthEast",'NumColumns',1);
set(h, "fontSize",16); legend("boxoff")

end