function Err = Error(mpar,PerFlow,BileFlow,PerVolume,IC,tData,PerfusateData,BileData)

% Simulate model
p = Parameters(mpar,PerFlow,BileFlow,PerVolume); %load parameters into model
y0 = [IC 0 0 0 0 0 0 0 0 0]; % Initial concentrations in mg/ml 

options = odeset('RelTol',1e-6,'AbsTol',1e-6,'InitialStep',1e-2,...
    'NonNegative',(1:10),'MaxOrder',5,'BDF','on','Stats','off');

% Calculate model solution
ODE_FH = @(t,y)LiverModel(t,y,p);
sols = ode15s(ODE_FH,tData,y0,options);
y = deval(tData,sols);

% Assigning models
PerfusateModel = y(1,:)'; %mg/ml
BileModel = y(9,:)'; %mg/ml

% Calculate SSE
Err_Bile = sum(((BileModel-BileData)/max(BileData)).^2,'omitnan');
Err_Perfusate = sum(((PerfusateModel-PerfusateData)/max(PerfusateData)).^2,'omitnan');
Err = Err_Bile + 2*Err_Perfusate;
end
