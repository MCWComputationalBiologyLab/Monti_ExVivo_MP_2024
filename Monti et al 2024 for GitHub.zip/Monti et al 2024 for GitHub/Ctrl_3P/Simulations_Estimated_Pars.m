%%========================================================================
close all; clear all; clc;

%%========================================================================
%% Load calibrated experimental data
C1 = load('Control_ExVivo_Perfusate_C_Data_NLR_Avg_SD_SEM.txt');
tData = C1(:,1);
PerfusateData = C1(:,2);
PerfusateSD = C1(:,3);
PerfusateSEM = C1(:,4);
PerFlow = C1(:,5);
PerFlow = mean(PerFlow);

C3 = load('Control_ExVivo_Bile_C_Data_NLR_Avg_SD_SEM.txt');
BileData = C3(:,2);
BileSD = C3(:,3);
BileSEM = C3(:,4);
BileVolume = C3(:,5);

%% Determine volume of reservior compartment 1 (injection and sampling)
Rat_Weight = 0.33559;    %kg
SF_Dose = 0.4;         %mg/kg
SF_Amount = Rat_Weight*SF_Dose; %mg
IC = PerfusateData(1);  % SF concentration in the reservior compartment 1 at time zero 
PerVolume = SF_Amount/IC;

%%========================================================================
%% Compute SF bile clearance rate (bile flow rate) using linear regression
x = [ones(length(tData),1),tData];
b = x\BileVolume;
intercept = b(1);
slope = b(2);    
BileFlow = slope; %bile flow rate; ml/min

%%========================================================================
%% Simulate model with estimated model parameters
load('Ctrl_mpar.mat');
p = Parameters(mpar,PerFlow,BileFlow,PerVolume); %load parameters into model
y0 = [IC 0 0 0 0 0 0 0 0 0]; % Initial concentrations in mg/ml  % Initial concentrations in mg/ml

tf = 1;
tspan = tf*(0:1:60);

options = odeset('RelTol',1e-6,'AbsTol',1e-6,'InitialStep',1e-2,...
    'NonNegative',(1:10),'MaxOrder',5,'BDF','on','Stats','off');

% Calculate model solution
ODE_FH = @(t,y)LiverModel(t,y,p);
sols = ode15s(ODE_FH,tspan,y0,options);
y = deval(tspan,sols);

% Assigning model solutions
PerfusateModel1_SF = y(1,:)';            %mg/ml
PerfusateModel1_SFG = y(2,:)';           %mg/ml
PerfusateModel2_SF = y(3,:)';            %mg/ml
PerfusateModel2_SFG = y(4,:)';           %mg/ml
SinusoidModel_SF = y(5,:)';              %mg/ml
SinusoidModel_SFG = y(6,:)';             %mg/ml
HepatocyteModel_SF = y(7,:)';            %mg/ml
HepatocyteModel_SFG = y(8,:)';           %mg/ml
BileModel_SF = y(9,:)';                  %mg/ml
BileModel_SFG = y(10,:)';                %mg/ml

%%========================================================================
%% Plot model solutions
figure(1); set(gcf,'Units','inches','Position',[0.5 0.5 7 5]);
set(gcf,'Units','inches','PaperPosition',[0.5 0.5 7 5],'color','white');
plot(tspan,100*PerfusateModel1_SF,'-r','LineWidth',2.5); hold on;
errorbar(tData,PerfusateData*100,PerfusateSEM*100,'o','MarkerSize',8,'MarkerFaceColor',...
    'r','MarkerEdgeColor','r','LineWidth',2.5,'Color','r','CapSize',6); hold on;
plot(tspan,100*BileModel_SF,'-g','LineWidth',2); hold on;
errorbar(tData,BileData*100,BileSEM*100,'o','MarkerSize',8,'MarkerFaceColor',...
    'g','MarkerEdgeColor','g','LineWidth',2.5,'Color','g','CapSize',6); hold on;
axis([0 tf*60 0 1]); box on; grid off
set(gca,'LineWidth',1.5,'FontSize',24,'FontName','Arial'); box off;
set(gca,'XTick',tf*(0:10:60),'YTick',(0:0.2:1));
xlabel("Time (min)"); ylabel(sprintf("Concentration x 10^2\n(mg/mL)"))
h = legend("Perfusate Model","Perfusate Data","Bile Model","Bile Data",...
    "Location","NorthEast",'NumColumns',1);
set(h, "fontSize",20,'FontName','Arial'); legend("boxoff")

% figure(2); set(gcf,'Units','inches','Position',[0.5 0.5 12 5]);
% set(gcf,'Units','inches','PaperPosition',[0.5 0.5 11.7 4.4],'color','white');
% subplot(1,2,1);
% plot(tspan,100*PerfusateModel1_SF,'-r','LineWidth',2); hold on;
% plot(tspan,100*PerfusateModel2_SF,'-c','LineWidth',2); hold on;
% plot(tspan,100*SinusoidModel_SF,'-b','LineWidth',2); hold on;
% plot(tspan,100*HepatocyteModel_SF,'-m','LineWidth',2); hold on;
% plot(tspan,100*BileModel_SF,'-g','LineWidth',2); hold on;
% axis([0 tf*60 0 1]); box on; grid off
% set(gca,'LineWidth',1.5,'FontSize',18); box off;
% set(gca,'XTick',tf*(0:10:60),'YTick',(0:0.2:1));
% xlabel("Time (min)"); ylabel("Concentration x 10^2 (mg/mL)")
% h = legend("Reservoir1","Reservior2","Sinusoid",...
%     "Hepatocyte","Bile","Location","NorthEast",'NumColumns',1);
% set(h, "fontSize",16); legend("boxoff")
% title('SF');
% 
% subplot(1,2,2);
% plot(tspan,10000*PerfusateModel1_SFG,'-r','LineWidth',2); hold on;
% plot(tspan,10000*PerfusateModel2_SFG,'-c','LineWidth',2); hold on;
% plot(tspan,10000*SinusoidModel_SFG,'-b','LineWidth',2); hold on;
% plot(tspan,10000*HepatocyteModel_SFG,'-m','LineWidth',2); hold on;
% plot(tspan,100*BileModel_SFG,'-g','LineWidth',2); hold on;
% axis([0 tf*60 0 10]); box on; grid off
% set(gca,'LineWidth',1.5,'FontSize',18); box off;
% set(gca,'XTick',tf*(0:10:60),'YTick',(0:2:10));
% xlabel("Time (min)"); ylabel("Concentration x 10^2 (mg/mL)")
% h = legend("100 x Reservoir1","100 x Reservior2","100 x Sinusoid",...
%     "100 x Hepatocyte","Bile","Location","NorthEast",'NumColumns',1);
% set(h, "fontSize",16); legend("boxoff")
% title('SFG');
% 
% figure(3); set(gcf,'Units','inches','Position',[0.5 0.5 7 5]);
% set(gcf,'Units','inches','PaperPosition',[0.5 0.5 7 5],'color','white');
% flux_SF = p.Vmax3*HepatocyteModel_SF./(p.Km3+HepatocyteModel_SF+HepatocyteModel_SFG);
% flux_SFG = p.CatFact2*p.Vmax3*HepatocyteModel_SFG./(p.Km3+HepatocyteModel_SFG+HepatocyteModel_SF);
% plot(tspan,flux_SF,'-g','LineWidth',2); hold on;
% plot(tspan,flux_SFG,'-.g','LineWidth',2); hold on;
% 
% %axis([0 tf*60 0 1.2]); 
% box on; grid off
% set(gca,'LineWidth',1.5,'FontSize',18); box off;
% %set(gca,'XTick',tf*(0:10:60),'YTick',(0:0.3:1.2));
% xlabel("Time (min)"); ylabel("Flux (mg/min)");
% h = legend("SF","SFG");
% set(h, "fontSize",16,'Location','NorthEast'); legend("boxoff");

