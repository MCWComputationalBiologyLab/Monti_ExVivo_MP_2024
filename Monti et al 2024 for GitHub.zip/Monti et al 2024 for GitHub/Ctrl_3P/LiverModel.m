function dy = LiverModel(t,y,p)

%% Explanation 
% Modified version of Monti et al, EMBC 2023, model to include a
% reservoir and ex vivo machine perfusion system for liver.

%% Assumptions
% In this version of the model, we assume that
% 1. The transport of SF and SFG by transport proteins is through competition, with 
% the same Km values but with significantly higher catalytic activity (higher Vmax) 
% of SFG compared to that of SF.
% 2. The OAT1B1/MRP3 coupled transporter acts as a single reversible transporter.

%% State variables
C1 = y(1);       %Concentration of SF in reservoir 1 (injection and sampling) (mg/ml)
C2 = y(2);       %Concentration of conjugated SF in reservoir 1 (injection and sampling) (mg/ml)
C3 = y(3);       %Concentration of SF in reservoir 2 (mixing, tubing, and circulation) (mg/ml)
C4 = y(4);       %Concentration of conjugated SF in reservoir 2 (mixing, tubing, and circulation) (mg/ml)
C5 = y(5);       %Concentration of SF in sinusoid (mg/ml)
C6 = y(6);       %Concentration of conjugated SF in sinusoid (mg/ml)
C7 = y(7);       %Concentration of SF in hepatocytes (mg/ml)
C8 = y(8);       %Concentration of conjugated SF in hepatocytes (mg/ml)
C9 = y(9);       %Concentration of SF in bile duct (mg/ml)
C10 = y(10);     %Concentration of conjugated SF in bile duct (mg/ml)

%% Model parameters
V1 = p.V1;                   %Volume in Reservoir compartment 1 (ml)
V2 = p.V2;                   %Volume in Reservior compartment 2 (ml)
V3 = p.V3;                   %Volume of Sinusoid compartment (ml)
V4 = p.V4;                   %Volume of Hepatocyte compartment (ml)
V5 = p.V5;                   %Volume of Bile compartment (ml)
F = p.F;                     %Flow in and out of capilary (set experimentally) (ml/min)
Kmix = p.Kmix;               %Mixing rate constant between Reservior compartments (ml/min)
Vmax1 = p.Vmax1;             %Max Velocity of OATPB1 transporter for transfer between capillary and hepatocytes
CatFact1 = p.CatFact1;       %SFG catalytic factor for OAT1B2/MRP3
Km1 = p.Km1;                 %MM Constant of SF for OATPB1 transporter for transfer between capillary and hepatocytes
Vmax2 = p.Vmax2;             %Max Velocity for SF conjugation within hepatocytes
Km2 = p.Km2;                 %MM Constant for SF conjugation within hepatocytes
Vmax3 = p.Vmax3;             %Max Velocity of MRP2 transporter for transfer between hepatocytes and bile duct
CatFact2 = p.CatFact2;       %SFG catalytic factor for MRP2
Km3 = p.Km3;                 %MM Constant for SF for MRP2 transporter for transfer between hepatocytes and bile duct
Fb = p.Fb;                   %Bile flow rate for clearance of SF from bile (ml/min)

%% Differential equations
dy = zeros(10,1);
dy(1) = (Kmix*(C3-C1))/V1;     % SF dynamics in reservoir 1
dy(2) = (Kmix*(C4-C2))/V1;     % SF conjugate dynamics in reservoir 1
dy(3) = (Kmix*(C1-C3) + F*(C5-C3))/V2;     % SF dynamics in reservior 2
dy(4) = (Kmix*(C2-C4) + F*(C6-C4))/V2;     % SF conjugate dynamics in reservior 2
dy(5) = (F*(C3-C5) - Vmax1*(C5-C7)/(Km1+C5+C6+C7+C8))/V3;            % SF dynamics in sinusoid
dy(6) = (F*(C4-C6) - CatFact1*Vmax1*(C6-C8)/(Km1+C5+C6+C7+C8))/V3;   % SF conjugate dynamics in sinusoid.
dy(7) = (Vmax1*(C5-C7)/(Km1+C5+C6+C7+C8) - Vmax2*C7/(Km2+C7) - Vmax3*C7/(Km3+C7+C8))/V4;                    % SF dynamics in hepatocytes
dy(8) = (CatFact1*Vmax1*(C6-C8)/(Km1+C5+C6+C7+C8) + Vmax2*C7/(Km2+C7) - CatFact2*Vmax3*C8/(Km3+C7+C8))/V4;  % SF conjugate dynamics in hepatocytes. Only has unidirectional flow out of hepatocyte via MRP3
dy(9) = (Vmax3*C7/(Km3+C7+C8) - Fb*C9)/V5;             % SF dynamics in bile duct
dy(10) = (CatFact2*Vmax3*C8/(Km3+C7+C8) - Fb*C10)/V5;  % SF conjugate dynamics in bile duct
end