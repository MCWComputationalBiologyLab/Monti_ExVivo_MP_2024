For the F-test, the formula is

F = DF2/SSE2*(SSE1-SSE2)/(DF1-DF2)

Where the subscript 2 is the more complex (6-parameter) model and the
subscript 1 is the less complex (3-parameter) model. DF is the degrees of
freedom (number of data points - number of parameters) and SSE is the SSE
using the mostFrequentlyEstimated parameters for the 6-parameter model. 
There is only one choice for the SSE for the 3-parameter model (mresid). 

These numbers are
SSE6 = 3.4115E-3
SSE3 = 3.4634E-3
Number of data points = 14 (perfusaste and bile!)
DF6 = 8
DF3 = 11

From this you should get a F value of 0.0406. 

To get a p value use the line of code 1-fcdf(F,11,8), where F is the
F-value. This code uses the F-distribution in MATLAB. 

(You need 1 minus to get the right tailed version)

P value should be 0.99. 

AIC = N*ln(SSE/N) + 2K + 2K(K+1)/(N-K-1)

Where N is the number of datapoints, and K is the number of parameters 
plus 1.

To get the probability of correctness of model with 3 parameters versus
model with 6 parameters use the formula

P = exp(-0.5*delta)/(1+exp(-0.5*delta))
Where delta is AIC3 - AIC6. 
