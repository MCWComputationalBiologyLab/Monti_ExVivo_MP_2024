function p = Parameters(mpars,PerFlow,BileFlow,PerVolume)

% Anatomical parameters are from Hall etal (2011) and Brown etal (1997)
LiverWeight = 17.78;                        %g
p.Vtot = LiverWeight;                       %volume of total liver of rat; ml
% LiverDensity = 1;                         %g/mL
% p.Vtot = LiverWeight/LiverDensity;        %volume of total liver of rat; ml
p.fV3 = 0.18;                               %fractional volume of liver that is sinusoid
p.fV4 = 0.82;                               %fractional volume of liver that is hepatocytes
p.fV5 = 0.004;                              %fractional volume of liver that is bile duct
p.Ve = 100;                                 %total volume in experimental apparatus; ml
p.V1 = PerVolume;                           %volume of Reservoir compartment 1; ml
p.V2 = p.Ve-PerVolume;                      %volume of Reservior compartment 2; ml
p.V3 = p.Vtot*p.fV3;                        %volume of Sinusoid compartment; ml
p.V4 = p.Vtot*p.fV4;                        %volume of Hepatocyte compartment; ml
p.V5 = p.Vtot*p.fV5;                        %volume of Bile compartment; ml 
p.F = PerFlow;                              %flow in and out of capilary, determined experimentally; ml/min
p.Kmix = PerFlow/mpars(3);                  %Mixing rate constant between Reservior compartments (ml/min)       

% Kinetic parameters for the liver SF clearance
p.Vmax1 = 1.5;                              %Max Velocity of OATPB1 transporter for transfer of SF between capillary and hepatocytes
p.CatFact1 = 3;                                %Max Velocity of OATPB1 transporter for transfer of SFG between capillary and hepatocytes
p.Km1 = 9.3E-3;                                %MM Constant of SF for OATPB1 transporter for transfer between capillary and hepatocytes
p.Vmax2 = mpars(1);                            %Max Velocity for SF conjugation within hepatocytes
p.Km2 = 5.8E-2;                                %MM Constant for SF conjugation within hepatocytes
p.Vmax3 = mpars(2);                            %Max Velocity of MRP2 transporter for transfer of SF between hepatocytes and bile duct
p.CatFact2 = 12.5;                               %Max Velocity of MRP2 transporter for transfer of SFG between hepatocytes and bile duct
p.Km3 = 5.8E-4;                                %MM Constant for SF for MRP2 transporter for transfer between hepatocytes and bile duct
p.Fb = BileFlow;                               %Rate at which bile flows into the collection tube. Determined as the slope of bile collection rate; units: mL/min
end
