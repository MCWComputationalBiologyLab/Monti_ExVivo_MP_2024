%%========================================================================
close all; clear all; clc;
% rng(1); % For reproducibility
format short e

%%========================================================================
%% Load calibrated experimental data
C1 = load('Control_ExVivo_Perfusate_C_Data_NLR_Avg_SD_SEM.txt');
tData = C1(:,1);
PerfusateData = C1(:,2);
PerfusateSD = C1(:,3);
PerfusateSEM = C1(:,4);
PerFlow = C1(:,5);
PerFlow = mean(PerFlow)

C3 = load('Control_ExVivo_Bile_C_Data_NLR_Avg_SD_SEM.txt');
BileData = C3(:,2);
BileData = BileData - BileData(1);
BileSD = C3(:,3);
BileSEM = C3(:,4);
BileVolume = C3(:,5);

%% Determine volume of reservior compartment 1 (injection and sampling)
Rat_Weight = 0.33559;    %kg
SF_Dose = 0.4;         %mg/kg
SF_Amount = Rat_Weight*SF_Dose; %mg
IC = PerfusateData(1);  % SF concentration in the reservior compartment 1 at time zero 
PerVolume = SF_Amount/IC

%%========================================================================
%% Compute SF bile clearance rate (bile flow rate) using linear regression
x = [ones(length(tData),1),tData];
b = x\BileVolume;
intercept = b(1);
slope = b(2);    
BileFlow = slope  %bile flow rate; ml/min

%%========================================================================
%% fmincon optimization
options = optimset('fmincon');
%options = optimset(options,'algorithm','sqp');
options = optimset(options,'TolFun',1e-4,'TolX',1e-6);
options = optimset(options,'Display','iter');
%options = optimset(options,'Maxiter',100,'MaxFunEvals',1000);
%options = optimset(options,'UseParallel','always');
%options = []; % We want to use only default optimizer options

numIters = 1000;
mpars = []; fvals = [];

randLb = 0.5; randUb = 1.5;

p0 = [2.6E-1,2,2E-1,2E-4,12,3];
numPars = length(p0);

parfor i = 1:numIters
    p = p0;
    randNum = (randLb + (randUb-randLb)*rand(1,numPars));
    %Generates random number b/w 0.5 and 1.5 effectively allowing p0 to
    %vary between 0.5p0 and 1.5p0 (a maximal increase or decrease of 50%) 

    p = p.*randNum;
    lbp = p/10; ubp = p*10;
    %p(3) = p0(3); lbp(3) = p(3)/1; ubp(3) = p(3)*1;  % Kmix
    lbp(6) = 1; ubp(6) = 5;  % Kmix
    [mpar,fval] = fmincon(@Error,p,[],[],[],[],lbp,ubp,[],options,...
        PerFlow,BileFlow,PerVolume,IC,tData,PerfusateData,BileData);
    mpar
    fval

    figure(22)
    Fitting(mpar,PerFlow,BileFlow,PerVolume,IC,tData,PerfusateData,BileData,PerfusateSEM,BileSEM,gcf);  % Plot model simulation

    mpars(i,:) = mpar;
    fvals(i) = fval;
end
%% Post processing
[minFval,minIdx] = min(fvals);
mpar = mpars(minIdx,:);
minFval
mpar
%% Histograms
mostFreqMpars = [];

figure(1); set(gcf,'Units','inches','Position',[0.5 0.5 14 2.5]);
set(gcf,'Units','inches','PaperPosition',[0.5 0.5 14 2.5],'color','white');

 parTitles = ["V_{max,1,SF}","\beta_{1}","V_{max,2}","V_{max,3,SF} x 10^{-4}","\beta_{2}","\alpha"];
%parTitles = ["V_{max,1,SF}","V_{max,1,SFG}","V_{max,2}","V_{max,3,SF} x 10^{4}","V_{max,3,SFG}","K_{mix}"];


for i = 1:numPars
    figure(1);
    subplot(1,6,i);
    toPlot = mpars(:,i);
    if i == 4
        toPlot = toPlot*10^4; %for formatting
    end
    h = histogram(toPlot);
    vals = h.Values;
    [M,I] = max(vals);
    BEs = h.BinEdges;
    midPt = (BEs(I) + BEs(I+1))/2;
    mostFreqMpars(i) = midPt;

    set(gca,'LineWidth',1.5,'FontSize',14); box off;
    xlabel(parTitles(i)); ylabel("Count")
    if i == 5
        axis([0 28 0 1000]);
        set(gca,'XTick',[0 14 28]);
    elseif i == 3
        axis([0.15 0.3 0 1000]);
        set(gca,'XTick',[0.15 0.23 0.3]);
        set(gca,'xticklabel',num2str(get(gca,'xtick')','%.1f'))
    elseif i == 4
        axis([2 2.5 0 1000]);
        set(gca,'XTick',[2.00 2.25 2.50]);
        set(gca,'xticklabel',num2str(get(gca,'xtick')','%.2f'))
    elseif i == 6
        axis([2.2 2.9 0 400]);
        set(gca,'XTick',[2.2 2.55 2.9]);
        set(gca,'xticklabel',num2str(get(gca,'xtick')','%.2f'))
    elseif i == 1
        axis([-0.1 3 0 150]);
        set(gca,'XTick',[0 1.5 3],'YTick',[0 75 150]);
        set(gca,'xticklabel',num2str(get(gca,'xtick')','%.1f'))
    elseif i == 2
        axis([-1 20 0 310]);
        set(gca,'XTick',[0 10 20],'YTick',[0 155 310]);
    end
end

%% Plot most frequent pars
mostFreqMpars(4) = mostFreqMpars(4)*10^-4; % need to undo the formatting
figure(32);
Fitting(mostFreqMpars,PerFlow,BileFlow,PerVolume,IC,tData,PerfusateData,BileData,PerfusateSEM,BileSEM,gcf);  % Plot model simulation with most freq mpars

%% Saving
save('Ctrl_mpar.mat','mpar');
save('Ctrl_resid.mat','minFval');
