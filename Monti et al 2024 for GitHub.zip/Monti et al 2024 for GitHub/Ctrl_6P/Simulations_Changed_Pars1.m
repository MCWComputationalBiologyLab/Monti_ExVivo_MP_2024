%%========================================================================
close all; clear all; clc;

%%========================================================================
%% Load calibrated experimental data
C1 = load('Control_ExVivo_Perfusate_C_Data_NLR_Avg_SD_SEM.txt');
tData = C1(:,1);
PerfusateData = C1(:,2);
PerfusateSD = C1(:,3);
PerfusateSEM = C1(:,4);
PerFlow = C1(:,5);
PerFlow = mean(PerFlow);

C3 = load('Control_ExVivo_Bile_C_Data_NLR_Avg_SD_SEM.txt');
BileData = C3(:,2);
BileSD = C3(:,3);
BileSEM = C3(:,4);
BileVolume = C3(:,5);

%% Determine volume of reservior compartment 1 (injection and sampling)
Rat_Weight = 0.325;    %kg
SF_Dose = 0.4;         %mg/kg
SF_Amount = Rat_Weight*SF_Dose; %mg
IC = PerfusateData(1);  % SF concentration in the reservior compartment 1 at time zero 
PerVolume = SF_Amount/IC;

%%========================================================================
%% Compute SF bile clearance rate (bile flow rate) using linear regression
x = [ones(length(tData),1),tData];
b = x\BileVolume;
intercept = b(1);
slope = b(2);    
BileFlow = slope; %bile flow rate; ml/min

%%========================================================================
%% Initialize figures
titles = ["\DeltaV_{max,1}","\DeltaCatFact_{1}","\DeltaV_{max,2}","\DeltaV_{max,3}","\DeltaCatFact_{2}","K_{mix}",...
    "\DeltaPerFlow","\DeltaBileFlow","\DeltaIC"];
for i = 1:length(titles)
    figure(i); set(gcf,'Units','inches','Position',[0.5 0.5 20 8]);
    set(gcf,'Units','inches','PaperPosition',[0.5 0.5 20 8],'color','white');
    sgtitle(titles(i),'FontSize',16);
end

%%========================================================================
%% Setup code for simulations
tf = 2;
tspan = tf*(0:1:60);

options = odeset('RelTol',1e-6,'AbsTol',1e-6,'InitialStep',1e-2,...
    'NonNegative',(1:10),'MaxOrder',5,'BDF','on','Stats','off');

%%========================================================================
%% Simulate model with estimated model parameters
load('Ctrl_mpar.mat');
mpar0 = mpar;
PerFlow0 = PerFlow;
BileFlow0 = BileFlow;
IC0 = IC;

ParsToChange = [mpar,PerFlow,BileFlow,IC];

for i = 1:length(ParsToChange)
    for j = 1:31    
        if i == 7
            mpar = mpar0;
            PerFlow = PerFlow0*(41-j)/20;
        elseif i == 8
            mpar = mpar0;
            PerFlow = PerFlow0;
            BileFlow = BileFlow0*(41-j)/20;
        elseif i == 9
            mpar = mpar0;
            PerFlow = PerFlow0;
            BileFlow = BileFlow0;
            IC = IC0*(41-j)/20;
        else
            mpar = mpar0;
            mpar(i) = mpar0(i)*(41-j)/20;
        end
    
        p = Parameters(mpar,PerFlow,BileFlow,PerVolume); %load parameters into model
        y0 = [IC 0 0 0 0 0 0 0 0 0]; % Initial concentrations in mg/ml  % Initial concentrations in mg/ml
        
        % Calculate model solution
        ODE_FH = @(t,y)LiverModel(t,y,p);
        sols = ode15s(ODE_FH,tspan,y0,options);
        y = deval(tspan,sols);
        
        % Assigning model solutions
        PerfusateModel1_SF = y(1,:)';            %mg/ml
        PerfusateModel1_SFG = y(2,:)';           %mg/ml
        PerfusateModel2_SF = y(3,:)';            %mg/ml
        PerfusateModel2_SFG = y(4,:)';           %mg/ml
        SinusoidModel_SF = y(5,:)';              %mg/ml
        SinusoidModel_SFG = y(6,:)';             %mg/ml
        HepatocyteModel_SF = y(7,:)';            %mg/ml
        HepatocyteModel_SFG = y(8,:)';           %mg/ml
        BileModel_SF = y(9,:)';                  %mg/ml
        BileModel_SFG = y(10,:)';                %mg/ml
        
        %%========================================================================
        %% Plot model solutions
        figure(i) 
        subplot(2,5,1);
        plot(tspan,100*PerfusateModel1_SF,'-r','LineWidth',2); hold on;
        ylabel(sprintf('Perfusate 1\nSF (mg/mL) x 10^2'));

        subplot(2,5,2)
        plot(tspan,100*PerfusateModel2_SF,'-c','LineWidth',2); hold on;
        ylabel(sprintf('Perfusate 2\nSF (mg/mL) x 10^2'));
        
        subplot(2,5,3)
        plot(tspan,100*SinusoidModel_SF,'-b','LineWidth',2); hold on;
        ylabel(sprintf('Sinusoid\nSF (mg/mL) x 10^2'));
        
        subplot(2,5,4)
        plot(tspan,100*HepatocyteModel_SF,'-m','LineWidth',2); hold on;
        ylabel(sprintf('Hepatocyte\nSF (mg/mL) x 10^2'));

        subplot(2,5,5)
        plot(tspan,100*BileModel_SF,'-g','LineWidth',2); hold on;
        ylabel(sprintf('Bile\nSF (mg/mL) x 10^2'));

        subplot(2,5,6)
        plot(tspan,100*PerfusateModel1_SFG,'-r','LineWidth',2); hold on;
        ylabel(sprintf('Perfusate 1\nSFG (mg/mL) x 10^2'));
        
        subplot(2,5,7)
        plot(tspan,100*PerfusateModel2_SFG,'-c','LineWidth',2); hold on;
        ylabel(sprintf('Perfusate 2\nSFG (mg/mL) x 10^2'));
        
        subplot(2,5,8)
        plot(tspan,100*SinusoidModel_SFG,'-b','LineWidth',2); hold on;
        ylabel(sprintf('Sinusoid\nSFG (mg/mL) x 10^2'));
        
        subplot(2,5,9)
        plot(tspan,100*HepatocyteModel_SFG,'-m','LineWidth',2); hold on;
        ylabel(sprintf('Hepatocyte\nSFG (mg/mL) x 10^2'));
        
        subplot(2,5,10)
        plot(tspan,100*BileModel_SFG,'-g','LineWidth',2); hold on;
        ylabel(sprintf("Bile\nSFG (mg/mL) x 10^2"));

    end
end

%% Plot unchanged model over simulations
mpar = mpar0;
PerFlow = PerFlow0;
BileFlow = BileFlow0;
IC = IC0;
p = Parameters(mpar,PerFlow,BileFlow,PerVolume); %load parameters into model
y0 = [IC 0 0 0 0 0 0 0 0 0]; % Initial concentrations in mg/ml  % Initial concentrations in mg/ml

tf = 2;
tspan = tf*(0:0.1:60);

options = odeset('RelTol',1e-6,'AbsTol',1e-6,'InitialStep',1e-2,...
    'NonNegative',(1:3),'MaxOrder',5,'BDF','on','Stats','off');

% Calculate model solution
ODE_FH = @(t,y)LiverModel(t,y,p);
sols = ode15s(ODE_FH,tspan,y0,options);
y = deval(tspan,sols);

% Assigning model solutions
PerfusateModel1_SF = y(1,:)';            %mg/ml
PerfusateModel1_SFG = y(2,:)';           %mg/ml
PerfusateModel2_SF = y(3,:)';            %mg/ml
PerfusateModel2_SFG = y(4,:)';           %mg/ml
SinusoidModel_SF = y(5,:)';              %mg/ml
SinusoidModel_SFG = y(6,:)';             %mg/ml
HepatocyteModel_SF = y(7,:)';            %mg/ml
HepatocyteModel_SFG = y(8,:)';           %mg/ml
BileModel_SF = y(9,:)';                  %mg/ml
BileModel_SFG = y(10,:)';                %mg/ml

for i = 1:length(ParsToChange)
    figure(i)
    subplot(2,5,1)
    plot(tspan,100*PerfusateModel1_SF,'-k','LineWidth',3); hold on;
    subplot(2,5,2)
    plot(tspan,100*PerfusateModel2_SF,'-k','LineWidth',3); hold on;
    subplot(2,5,3)
    plot(tspan,100*SinusoidModel_SF,'-k','LineWidth',3); hold on;
    subplot(2,5,4)
    plot(tspan,100*HepatocyteModel_SF,'-k','LineWidth',3); hold on;
    subplot(2,5,5)
    plot(tspan,100*BileModel_SF,'-k','LineWidth',3); hold on;
    subplot(2,5,6)
    plot(tspan,100*PerfusateModel1_SFG,'-k','LineWidth',3); hold on;
    subplot(2,5,7)
    plot(tspan,100*PerfusateModel2_SFG,'-k','LineWidth',3); hold on;
    subplot(2,5,8)
    plot(tspan,100*SinusoidModel_SFG,'-k','LineWidth',3); hold on;
    subplot(2,5,9)
    plot(tspan,100*HepatocyteModel_SFG,'-k','LineWidth',3); hold on;
    subplot(2,5,10)
    plot(tspan,100*BileModel_SFG,'-k','LineWidth',3); hold on;
end

%% Format plots
for i = 1:length(titles)
    figure(i);
    for j = 1:10
        subplot(2,5,j);
        box on; grid off
        xlim([0 tf*60]);
        set(gca,'LineWidth',1.5,'FontSize',16); box off;
        set(gca,'XTick',tf*(0:10:60));
        xlabel('Time (min)');
    end
end