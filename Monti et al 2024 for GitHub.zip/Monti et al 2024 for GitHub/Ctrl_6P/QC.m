function QC

close all; clear; clc
warning off; format short e

%% Load calibrated experimental data
C1 = load('Control_ExVivo_Perfusate_C_Data_NLR_Avg_SD_SEM.txt');
tData = C1(:,1);
PerfusateData = C1(:,2);
PerFlow = C1(:,5);
PerFlow = mean(PerFlow);

C3 = load('Control_ExVivo_Bile_C_Data_NLR_Avg_SD_SEM.txt');
BileData = C3(:,2);
BileVolume = C3(:,5);

%% Determine volume of reservior compartment 1 (injection and sampling)
Rat_Weight = 0.33559;    %kg
SF_Dose = 0.4;         %mg/kg
SF_Amount = Rat_Weight*SF_Dose; %mg
IC = PerfusateData(1);  % SF concentration in the reservior compartment 1 at time zero 
PerVolume = SF_Amount/IC

%% Compute SF bile clearance rate (bile flow rate) using linear regression
x = [ones(length(tData),1),tData];
b = x\BileVolume;
intercept = b(1);
slope = b(2);    
BileFlow = slope  %bile flow rate; ml/min

%% Load estimated model parameter values
load('Ctrl_MostFreqMpars_1000iter_Driver_013124.mat');
mpar = mostFreqMpars;

%% Run model simulations and compute residual vectors
tSpan = (0:1:60);  % Time span for integration and model simulations
[PerfusateModel,BileModel] = Model_Solution(mpar,PerFlow,BileFlow,PerVolume,IC,tSpan);
[Resid1,Resid2] = Error(mpar,PerFlow,BileFlow,PerVolume,IC,tData,PerfusateData,BileData);
% disp('Solution at optimization termination'); disp([PerfusateModel;BileModel]');
% disp('Residual at optimization termination'); disp([Resid1;Resid2]');
% disp('Function at optimization termination'); disp(sum([Resid1;Resid2].^2));

%% Plot model simulations compared to experimental data and residual vectors
figure(10); set(figure(10),'Units','inches','Position',[0.5 0.5 11 8]);
figure(10); subplot(2,2,1)
plot(tData,PerfusateData,'o','MarkerSize',6,'MarkerFaceColor','y',...
    'MarkerEdgeColor','r','LineWidth',2.0); hold on;
plot(tSpan,PerfusateModel,'-b','linewidth',2); hold on
set(gca,'LineWidth',1.25,'FontSize',16); box on;
xlabel('Time [hr]'); ylabel('SF Concentration [mg/L]');
h = legend('Data','Model','Location','NorthEast');
set(h,'FontSize',14); legend boxoff
title('Perfusate','FontSize',16);

figure(10); subplot(2,2,2)
plot(tData,Resid1,'o','MarkerSize',6,'MarkerFaceColor','y',...
    'MarkerEdgeColor','r','LineWidth',2.0); hold on;
plot(tSpan,PerfusateModel-PerfusateModel,'-b','linewidth',2); hold on
set(gca,'LineWidth',1.25,'FontSize',16); box on;
xlabel('Time [hr]'); ylabel('SF Residual [mg/L]');
h = legend('Model-Data','Model-Model','Location','NorthEast');
set(h,'FontSize',14); legend boxoff
title('Perfusate','FontSize',16);

figure(10); subplot(2,2,3)
plot(tData,BileData,'o','MarkerSize',6,'MarkerFaceColor','y',...
    'MarkerEdgeColor','r','LineWidth',2.0); hold on;
plot(tSpan,BileModel,'-b','linewidth',2); hold on
set(gca,'LineWidth',1.25,'FontSize',16); box on;
xlabel('Time [hr]'); ylabel('SF Concentration [mg/L]');
h = legend('Data','Model','Location','NorthEast');
set(h,'FontSize',14); legend boxoff
title('Bile','FontSize',16);

figure(10); subplot(2,2,4)
plot(tData,Resid2,'o','MarkerSize',6,'MarkerFaceColor','y',...
    'MarkerEdgeColor','r','LineWidth',2.0); hold on;
plot(tSpan,BileModel-BileModel,'-b','linewidth',2); hold on
set(gca,'LineWidth',1.25,'FontSize',16); box on;
xlabel('Time [hr]'); ylabel('SF Residual [mg/L]');
h = legend('Model-Data','Model-Model','Location','NorthEast');
set(h,'FontSize',14); legend boxoff
title('Bile','FontSize',16);
% saveas(gcf,'Model_Fitting_Data.jpg','jpg')

%% Compute jacobian matrices (sensitivity functions) and plot them
tSpan = (0:1:60);  % Time span for integration and model simulations
[Jacob1,Jacob2,Jacob1n,Jacob2n] = Model_Jacobian(mpar,PerFlow,BileFlow,PerVolume,IC,tSpan);
% disp('Jacobian at optimization termination'); disp([Jacob1;Jacob2]);
% disp('Normalized Jacobian at optimization termination'); disp([Jacob1n;Jacob2n]);

figure(20); set(figure(20),'Units','inches','Position',[0.5 0.5 11 8]);
figure(20); subplot(2,2,1)
plot(tSpan,Jacob1(:,1),'-b','linewidth',2); hold on;
plot(tSpan,Jacob1(:,2),'-r','linewidth',2); hold on;
plot(tSpan,Jacob1(:,3),'-g','linewidth',2); hold on;
plot(tSpan,Jacob1(:,4),'-m','linewidth',2); hold on;
plot(tSpan,Jacob1(:,5),'-c','linewidth',2); hold on;
plot(tSpan,Jacob1(:,6),'-k','linewidth',2); hold on;
set(gca,'LineWidth',1.25,'FontSize',16); box on;
xlim([0,20]); xlabel('Time [hr]'); ylabel('dPM/dPj');
h = legend('dPM/dV_{max,1}','dPM/dCatFact_{1}','dPM/dV_{max,2}','dPM/dV_{max,3}','dPM/dCatFact_{2}','Location','East');
set(h,'FontSize',14); legend boxoff
title('Perfusate','FontSize',16);

figure(20); subplot(2,2,2)
plot(tSpan,Jacob2(:,1),'-b','linewidth',2); hold on;
plot(tSpan,Jacob2(:,2),'-r','linewidth',2); hold on;
plot(tSpan,Jacob2(:,3),'-g','linewidth',2); hold on;
plot(tSpan,Jacob2(:,4),'-m','linewidth',2); hold on;
plot(tSpan,Jacob2(:,5),'-c','linewidth',2); hold on;
plot(tSpan,Jacob2(:,6),'-k','linewidth',2); hold on;
set(gca,'LineWidth',1.25,'FontSize',16); box on;
xlim([0,20]); xlabel('Time [hr]'); ylabel('dBM/dPj');
h = legend('dBM/dV_{max,1}','dBM/dCatFact_{1}','dBM/dV_{max,2}','dBM/dV_{max,3}','dBM/dCatFact_{2}','Location','East');
set(h,'FontSize',14); legend boxoff
title('Bile','FontSize',16);

figure(20); subplot(2,2,3)
plot(tSpan,Jacob1n(:,1),'-b','linewidth',2); hold on;
plot(tSpan,Jacob1n(:,2),'-r','linewidth',2); hold on;
plot(tSpan,Jacob1n(:,3),'-g','linewidth',2); hold on;
plot(tSpan,Jacob1n(:,4),'-m','linewidth',2); hold on;
plot(tSpan,Jacob1n(:,5),'-c','linewidth',2); hold on;
plot(tSpan,Jacob1n(:,6),'-k','linewidth',2); hold on;
set(gca,'LineWidth',1.25,'FontSize',16); box on;
xlim([0,20]); xlabel('Time [hr]'); ylabel('dlnPM/dlnPj');
h = legend('dlnPM/dlnV_{max,1}','dlnPM/dlnCatFact_{1}','dlnPM/dlnV_{max,2}','dlnPM/dlnV_{max,3}','dlnPM/dlnCatFact_{2}','Location','East');
set(h,'FontSize',14); legend boxoff
title('Perfusate','FontSize',16);

figure(20); subplot(2,2,4)
plot(tSpan,Jacob2n(:,1),'-b','linewidth',2); hold on;
plot(tSpan,Jacob2n(:,2),'-r','linewidth',2); hold on;
plot(tSpan,Jacob2n(:,3),'-g','linewidth',2); hold on;
plot(tSpan,Jacob2n(:,4),'-m','linewidth',2); hold on;
plot(tSpan,Jacob2n(:,5),'-c','linewidth',2); hold on;
plot(tSpan,Jacob2n(:,6),'-k','linewidth',2); hold on;
set(gca,'LineWidth',1.25,'FontSize',16); box on;
xlim([0,20]); xlabel('Time [hr]'); ylabel('dlnBM/dlnPj');
h = legend('dlnBM/dlnV_{max,1}','dlnBM/dlnCatFact_{1}','dlnBM/dlnV_{max,2}','dlnBM/dlnV_{max,3}','dlnBM/dlnCatFact_{2}','Location','East');
set(h,'FontSize',14); legend boxoff
title('Bile','FontSize',16);
% saveas(gcf,'Parameter_Sensitivity_Matrix.jpg','jpg')

%% Compute Jacobian matrix using tData and compute correlation matrix and confidence interval
[Jacob1,Jacob2,Jacob1n,Jacob2n] = Model_Jacobian(mpar,PerFlow,BileFlow,PerVolume,IC,tData);
% disp('Jacobian at optimization termination'); disp([Jacob1;Jacob2]);
% disp('Normalized Jacobian at optimization termination'); disp([Jacob1n;Jacob2n]);

Resid = [Resid1;Resid2];
Jacob = [Jacob1;Jacob2];
HH = inv(Jacob'*Jacob);
for i = 1:length(mpar)
    for j = 1:length(mpar)
        CM(i,j) = HH(i,j)/((HH(i,i)*HH(j,j))^0.5);
    end
end
%disp('Correlation matrix'); disp(full(CM));
CI = nlparci(mpar,Resid,'Jacobian',Jacob);
disp('Confidence interval'); disp(CI);

%% Plot correlation matrix
% for i=1:size(CM,1)
%     for j=1:size(CM,2)
%         if i<j
%             CM(i,j)=0;
%         end
%     end
% end

rgmap=ones(22,3);
rgmap(1:11,1)=(0:0.1:1);
rgmap(1:11,2)=(0:0.1:1);
rgmap(12:22,2)=(1:-0.1:0);
rgmap(12:22,3)=(1:-0.1:0);

xvalues={'V_{max,1,SF}','V_{max,1,SFG}','V_{max,2}','V_{max,3,SF}','V_{max,3,SFG}','K_{mix}'};
yvalues={'V_{max,1,SF}','V_{max,1,SFG}','V_{max,2}','V_{max,3,SF}','V_{max,3,SFG}','K_{mix}'};

figure(30); set(figure(30),'Units','inches','Position',[0.5 0.5 7 5])
h=heatmap(xvalues,yvalues,CM,'Colormap',rgmap,'GridVisible','on');
% h=heatmap(xvalues,yvalues,CM,'Colormap',redgreencmap,'GridVisible','on');
set(gcf,'color','w'); set(gca,'Fontsize',20,'FontName','Arial')
% saveas(gcf,'Parameter_Correlation_Matrix.jpg','jpg')

%% Compute parameter sensitivity coefficients and plot them
[dE_dP,dlnE_dlnP] = Error_Gradient(mpar,PerFlow,BileFlow,PerVolume,IC,tData,PerfusateData,BileData);
disp('Sensitivity coefficients of cost funtion w.r.t. parameters'); disp(dE_dP');
disp('Normalized sensitivity coefficients of cost funtion w.r.t. parameters'); disp(dlnE_dlnP');

figure(40); set(figure(40),'Units','inches','Position',[0.5 0.5 8 5])
figure(40); subplot(1,2,1); bar(dE_dP);
set(gca,'LineWidth',1.0,'FontSize',16,'FontName','Times New Roman'); box on; 
xlabel('Parameters','FontSize',14,'FontName','Times New Roman');
ylabel('Sensitivity coefficients of cost function','FontSize',14,'FontName','Times New Roman');

figure(40); subplot(1,2,2); bar(dlnE_dlnP);
set(gca,'LineWidth',1.0,'FontSize',16,'FontName','Times New Roman')
xlabel('Parameters','FontSize',14,'FontName','Times New Roman');
ylabel('Normalized sensitivity coefficients of cost function','FontSize',14,'FontName','Times New Roman');

%% Compute parameter sensitivity of cost function and plot them
[NormE_mat,NormP_mat] = NormE_NormP_Matrix(mpar,PerFlow,BileFlow,PerVolume,IC,tData,PerfusateData,BileData);
%disp('Normalized SSR matrix at optimization termination'); disp(NormE_mat);
%disp('Normalized parameter matrix at optimization termination'); disp(NormP_mat);

figure(51); set(figure(51),'Units','inches','Position',[0.5 0.5 7 5],'Color','White')
plot(NormP_mat(:,1),NormE_mat(:,1),'-b','linewidth',2); hold on;
plot(NormP_mat(:,2),NormE_mat(:,2),'-r','linewidth',2); hold on;
plot(NormP_mat(:,3),NormE_mat(:,3),'-g','linewidth',2); hold on;
plot(NormP_mat(:,4),NormE_mat(:,4),'-m','linewidth',2); hold on;
plot(NormP_mat(:,5),NormE_mat(:,5),'-c','linewidth',2); hold on;
plot(NormP_mat(:,6),NormE_mat(:,6),'-k','linewidth',2); hold on;
set(gca,'LineWidth',2.5,'FontSize',24,'FontName','Arial'); box off;
xlim([0.5,1.5]); xlabel('P/P_0'); ylabel('SSR/SSR_0');
%h = legend('V_{max,1,SF}','V_{max,1,SFG}','V_{max,2}','V_{max,3,SF}','V_{max,3,SFG}','K_{mix}','Location','North');
h = legend("V_{max,1,SF}","\beta_{1}","V_{max,2}","V_{max,3,SF}","\beta_{2}","K_{mix}",'Location','North');
set(h,'FontSize',18,'FontName','Arial'); legend boxoff
%title('Normalized SSR vs. Normalized P','FontSize',16);

figure(52); set(figure(52),'Units','inches','Position',[0.5 0.5 7 5])
semilogy(NormP_mat(:,1),NormE_mat(:,1),'-b','linewidth',2); hold on;
semilogy(NormP_mat(:,2),NormE_mat(:,2),'-r','linewidth',2); hold on;
semilogy(NormP_mat(:,3),NormE_mat(:,3),'-g','linewidth',2); hold on;
semilogy(NormP_mat(:,4),NormE_mat(:,4),'-m','linewidth',2); hold on;
semilogy(NormP_mat(:,5),NormE_mat(:,5),'-c','linewidth',2); hold on;
semilogy(NormP_mat(:,6),NormE_mat(:,6),'-k','linewidth',2); hold on;
set(gca,'LineWidth',1.25,'FontSize',18,'FontName','Arial'); box on;
xlim([0.5,1.5]); xlabel('P/P_0'); ylabel('SSR/SSR_0');
h = legend('V_{max,1,SF}','V_{max,1,SFG}','V_{max,2}','V_{max,3,SF}','V_{max,3,SFG}','K_{mix}','Location','North');
set(h,'FontSize',16,'FontName','Arial'); legend boxoff
%title('Normalized SSR vs. Normalized P','FontSize',16);
% saveas(gcf,'NormE_NormP_Matrix.jpg','jpg')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Define residuals and sum of squares of the residuals (cost function)
function varargout = Error(mpar,PerFlow,BileFlow,PerVolume,IC,tData,PerfusateData,BileData)

% Simulate model
[PerfusateModel,BileModel] = Model_Solution(mpar,PerFlow,BileFlow,PerVolume,IC,tData);

% Calculate SSE
Resid_Bile = (BileModel-BileData)/max(BileData);
Resid_Perfusate = (PerfusateModel-PerfusateData)/max(PerfusateData);
Resid = [Resid_Perfusate;Resid_Bile];

SSR1 = sum(Resid_Bile.^2);
SSR2 = sum(Resid_Perfusate.^2);
SSR = SSR1 + 2*SSR2;

% Set output argument variables
if (nargout == 1)
    varargout = {SSR};
else
    varargout = {Resid_Perfusate,Resid_Bile};
end

%% Evaluate the cost function in the neighborhood of the optimal parameter estimates
function [NormE_mat,NormP_mat] = NormE_NormP_Matrix(mpar,PerFlow,BileFlow,PerVolume,IC,tData,C1data,C2data)

mpar0 = mpar;  % Current parameter values for calculating the cost function
Err0 = Error(mpar0,PerFlow,BileFlow,PerVolume,IC,tData,C1data,C2data); % calculate the cost function

del_Pfact = 0.05;
max_Pfact = 0.5;
NP = max_Pfact/del_Pfact;

NormP_mat = [];
NormE_mat = [];

for i = 1:length(mpar)
    curr_mpar = mpar(i);
    dcurr_mpar = curr_mpar*del_Pfact;

    mparPs = []; mparMs = [];
    ErrPs = []; ErrMs = [];

   for j = 1:NP
       mparP = mpar;
       mparP(i) = curr_mpar + j*dcurr_mpar;
       ErrP = Error(mparP,PerFlow,BileFlow,PerVolume,IC,tData,C1data,C2data);
       mparPs = [mparPs;mparP(i)];
       ErrPs = [ErrPs;ErrP];
       
       mparM = mpar;
       mparM(i) = curr_mpar - j*dcurr_mpar;
       ErrM = Error(mparM,PerFlow,BileFlow,PerVolume,IC,tData,C1data,C2data);
       mparMs = [mparM(i);mparMs];
       ErrMs = [ErrM;ErrMs];
   end
   
    NormP_vec = [mparMs;curr_mpar;mparPs]/curr_mpar;
    NormE_vec = [ErrMs;Err0;ErrPs]/Err0;
    NormP_mat = [NormP_mat NormP_vec];
    NormE_mat = [NormE_mat NormE_vec];
end

%% Compute model parameter sensitivity coefficients of the cost function
function [dE_dP,dlnE_dlnP] = Error_Gradient(mpar,PerFlow,BileFlow,PerVolume,IC,tData,C1data,C2data)

mpar0 = mpar;  % Current parameter values for calculating the cost function
Err0 = Error(mpar0,PerFlow,BileFlow,PerVolume,IC,tData,C1data,C2data); % calculate the cost function

dE_dP = zeros(length(mpar),1); 
dlnE_dlnP = zeros(length(mpar),1);

% Calculate sensitivity coefficients numerically by central difference method
dmpar = 1e-3;  % Fractional change in each parameter values (should be <= 0.1%)
for i = 1:length(mpar)
    mpar1 = mpar;
    mpar1(i) = mpar(i) + dmpar*mpar(i);
    Err1 = Error(mpar1,PerFlow,BileFlow,PerVolume,IC,tData,C1data,C2data);
    
    mpar2 = mpar;
    mpar2(i) = mpar(i) - dmpar*mpar(i);
    Err2 = Error(mpar2,PerFlow,BileFlow,PerVolume,IC,tData,C1data,C2data);
    
    dE_dP(i) = (Err1 - Err2)/(2*dmpar*mpar(i));
    dlnE_dlnP(i) = (Err1 - Err2)/(2*dmpar*Err0);
end

%% Compute model Jacobian matrices at the optimal parameter estimates
function [Jacob1,Jacob2,Jacob1n,Jacob2n] = Model_Jacobian(mpar,PerFlow,BileFlow,PerVolume,IC,tData)

Jacob1 = zeros(length(tData),length(mpar)); 
Jacob1n = zeros(length(tData),length(mpar));
Jacob2 = zeros(length(tData),length(mpar)); 
Jacob2n = zeros(length(tData),length(mpar));

% Model solutions at the current parameter estimates
[C1model,C2model] = Model_Solution(mpar,PerFlow,BileFlow,PerVolume,IC,tData);

% Calculate Jacobian matrix numerically by central difference method
dmpar = 1e-3;  % Fractional change in each parameter values (should be <= 0.1%)
for i = 1:length(mpar)
    mpar1 = mpar;
    mpar1(i) = mpar(i) + dmpar*mpar(i);
    [C1model1,C2model1] = Model_Solution(mpar1,PerFlow,BileFlow,PerVolume,IC,tData);
    
    mpar2 = mpar;
    mpar2(i) = mpar(i) - dmpar*mpar(i);
    [C1model2,C2model2] = Model_Solution(mpar2,PerFlow,BileFlow,PerVolume,IC,tData);
    
    Jacob1(:,i) = (C1model1 - C1model2)/(2*dmpar*mpar(i));
    Jacob2(:,i) = (C2model1 - C2model2)/(2*dmpar*mpar(i));
    Jacob1n(:,i) = (C1model1 - C1model2)./(2*dmpar*C1model);
    Jacob2n(:,i) = (C2model1 - C2model2)./(2*dmpar*C2model);
end

%% Solve ODEs and compute model solutions
function varargout = Model_Solution(mpar,PerFlow,BileFlow,PerVolume,IC,tData)

% Simulate model
p = Parameters(mpar,PerFlow,BileFlow,PerVolume); %load parameters into model
y0 = [IC 0 0 0 0 0 0 0 0 0]; % Initial concentrations in mg/ml 

options = odeset('RelTol',1e-6, 'AbsTol',1e-6, 'InitialStep',1e-2,...
    'NonNegative',(1:3), 'MaxOrder',5, 'BDF','on', 'Stats','off');

% Calculate model solution
ODE_FH = @(t,y)LiverModel(t,y,p);
sols = ode15s(ODE_FH,tData,y0,options);
y = deval(tData,sols);

% Assigning models
PerfusateModel1_SF = y(1,:)';            %mg/ml
PerfusateModel1_SFG = y(2,:)';           %mg/ml
PerfusateModel2_SF = y(3,:)';            %mg/ml
PerfusateModel2_SFG = y(4,:)';           %mg/ml
SinusoidModel_SF = y(5,:)';              %mg/ml
SinusoidModel_SFG = y(6,:)';             %mg/ml
HepatocyteModel_SF = y(7,:)';            %mg/ml
HepatocyteModel_SFG = y(8,:)';           %mg/ml
BileModel_SF = y(9,:)';                  %mg/ml
BileModel_SFG = y(10,:)';                %mg/ml

Cmodel = [PerfusateModel1_SF;PerfusateModel1_SFG;PerfusateModel2_SF;...
    PerfusateModel2_SFG;SinusoidModel_SF;SinusoidModel_SFG;...
    HepatocyteModel_SF;HepatocyteModel_SFG;BileModel_SF;BileModel_SFG];

% Set output argument variables
if (nargout == 1)
    varargout = {Cmodel};
else
    varargout = {PerfusateModel1_SF,BileModel_SF};
end