%%========================================================================
close all; clear all; clc;

%%========================================================================
%% Load calibrated experimental data
C1 = load('Control_ExVivo_Perfusate_C_Data_NLR_Avg_SD_SEM.txt');
tData = C1(:,1);
PerfusateData = C1(:,2);
PerfusateSD = C1(:,3);
PerfusateSEM = C1(:,4);
PerFlow = C1(:,5);
PerFlow = mean(PerFlow);

C3 = load('Control_ExVivo_Bile_C_Data_NLR_Avg_SD_SEM.txt');
BileData = C3(:,2);
BileSD = C3(:,3);
BileSEM = C3(:,4);
BileVolume = C3(:,5);

%% Determine volume of reservior compartment 1 (injection and sampling)
Rat_Weight = 0.325;    %kg
SF_Dose = 0.4;         %mg/kg
SF_Amount = Rat_Weight*SF_Dose; %mg
IC = PerfusateData(1);  % SF concentration in the reservior compartment 1 at time zero 
PerVolume = SF_Amount/IC;

%%========================================================================
%% Compute SF bile clearance rate (bile flow rate) using linear regression
x = [ones(length(tData),1),tData];
b = x\BileVolume;
intercept = b(1);
slope = b(2);    
BileFlow = slope; %bile flow rate; ml/min

%%========================================================================
%% Simulate model with estimated model parameters
load('Ctrl_MostFreqMpars_1000iter_Driver_013124.mat');
ParChange0 = [mostFreqMpars,PerFlow,BileFlow,IC];
% titles = ["V_{max,1,SF}","V_{max,1,SFG}","V_{max,2}","V_{max,3,SF}","V_{max,3,SFG}","K_{mix}",...
%     "Perfusate Flow","Bile Flow","Dose"];
titles = ["V_{max,1,SF}","\beta_{1}","V_{max,2}","V_{max,3,SF}","\beta_{2}","\alpha",...
    "Perfusate Flow","Bile Flow","Dose"];

figure(1); set(gcf,'Units','inches','Position',[0.5 0.5 16 12]);
set(gcf,'Units','inches','PaperPosition',[0.5 0.5 16 12],'color','white');

for i = 1:9
for j = 1:31
    ParChange = ParChange0;
    ParChange(i) = ParChange(i)*(41-j)/20;
    mpar = ParChange(1:6);
    PerFlow = ParChange(7);
    BileFlow = ParChange(8);
    IC = ParChange(9);
    
    p = Parameters(mpar,PerFlow,BileFlow,PerVolume); %load parameters into model
    y0 = [IC 0 0 0 0 0 0 0 0 0]; % Initial concentrations in mg/ml  % Initial concentrations in mg/ml

    tf = 2;
    tspan = tf*(0:1:60);
    
    options = odeset('RelTol',1e-6,'AbsTol',1e-6,'InitialStep',1e-2,...
        'NonNegative',(1:10),'MaxOrder',5,'BDF','on','Stats','off');
    
    % Calculate model solution
    ODE_FH = @(t,y)LiverModel(t,y,p);
    sols = ode15s(ODE_FH,tspan,y0,options);
    y = deval(tspan,sols);
    
    % Assigning model solutions
    PerfusateModel1_SF = y(1,:)';            %mg/ml
    PerfusateModel1_SFG = y(2,:)';           %mg/ml
    PerfusateModel2_SF = y(3,:)';            %mg/ml
    PerfusateModel2_SFG = y(4,:)';           %mg/ml
    SinusoidModel_SF = y(5,:)';              %mg/ml
    SinusoidModel_SFG = y(6,:)';             %mg/ml
    HepatocyteModel_SF = y(7,:)';            %mg/ml
    HepatocyteModel_SFG = y(8,:)';           %mg/ml
    BileModel_SF = y(9,:)';                  %mg/ml
    BileModel_SFG = y(10,:)';                %mg/ml
    
    %% Plot model solutions
    subplot(3,3,i)
    plot(tspan,100*PerfusateModel1_SF,'-r','LineWidth',2); hold on;
    plot(tspan,100*BileModel_SF,'-g','LineWidth',2); hold on;
    xlim([0 tf*60]); ylim([0 1.5])
    set(gca,'LineWidth',1.5,'FontSize',22,'FontName','Arial'); box off;
    set(gca,'XTick',tf*(0:20:60),'YTick',(0:0.75:1.5));
    title(titles(i),'FontSize',24,'FontWeight','normal','FontName','Arial');
end
end

% Plot unchanged model over simulations
ParChange = ParChange0;
mpar = ParChange(1:6);
PerFLow = ParChange(7);
BileFlow = ParChange(8);
IC = ParChange(9);

tf = 2;
tspan = tf*(0:1:60);

options = odeset('RelTol',1e-6,'AbsTol',1e-6,'InitialStep',1e-2,...
    'NonNegative',(1:3),'MaxOrder',5,'BDF','on','Stats','off');

p = Parameters(mpar,PerFlow,BileFlow,PerVolume); %load parameters into model
y0 = [IC 0 0 0 0 0 0 0 0 0]; % Initial concentrations in mg/ml

% Calculate model solution
ODE_FH = @(t,y)LiverModel(t,y,p);
sols = ode15s(ODE_FH,tspan,y0,options);
y = deval(tspan,sols);

% Assigning model solutions
PerfusateModel1_SF = y(1,:)';            %mg/ml
PerfusateModel1_SFG = y(2,:)';           %mg/ml
PerfusateModel2_SF = y(3,:)';            %mg/ml
PerfusateModel2_SFG = y(4,:)';           %mg/ml
SinusoidModel_SF = y(5,:)';              %mg/ml
SinusoidModel_SFG = y(6,:)';             %mg/ml
HepatocyteModel_SF = y(7,:)';            %mg/ml
HepatocyteModel_SFG = y(8,:)';           %mg/ml
BileModel_SF = y(9,:)';                  %mg/ml
BileModel_SFG = y(10,:)';                %mg/ml

for i = 1:length(ParChange)
    subplot(3,3,i)
    plot(tspan,100*PerfusateModel1_SF,'-k','LineWidth',2); hold on;
    errorbar(tData,PerfusateData*100,PerfusateSEM*100,'o','MarkerSize',6,'MarkerFaceColor',...
    'k','MarkerEdgeColor','k','LineWidth',2,'Color','k','CapSize',8); hold on;
    plot(tspan,100*BileModel_SF,'-k','LineWidth',2); hold on;
    errorbar(tData,BileData*100,BileSEM*100,'o','MarkerSize',6,'MarkerFaceColor',...
    'k','MarkerEdgeColor','k','LineWidth',2,'Color','k','CapSize',8); hold on;
    if i == 1
        h = legend("SF Model","SF Data","","",...
        "Location","NorthEast",'NumColumns',1);
        set(h, "fontSize",20,'FontName','Arial'); legend("boxoff")
    end
    
    if mod((i + 2),3) == 0
        ylabel(sprintf("Concentration x 10^2\n(mg/mL)"));
    end
    
    if i > 6
        xlabel("Time (min)");
    end

end
